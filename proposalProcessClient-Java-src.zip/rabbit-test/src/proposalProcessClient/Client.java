package proposalProcessClient;

import java.util.Scanner;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.GetResponse;

public class Client {
	
	private static Channel channel;
	private static String uuid;
	private static int price;
	private static Scanner in;

	public static void main(String[] args) throws Exception {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("localhost");
		Connection connection = factory.newConnection();
		channel = connection.createChannel();
		in = new Scanner(System.in);
		
		while (true) {
	        String request = processMessage("requests");
	        if(request.length()>0) {
	        	determinePrice(request);
	        	sendQuotation();
	        }
	        String answer = processMessage("answers");
	        if(answer.length()>0) {
	        	printAnswer(answer);
	        }
		}

	}
	
	private static String processMessage(String queueName) throws Exception{
        channel.queueDeclare(queueName, false, false, false, null);
        GetResponse response = channel.basicGet(queueName, true);
        String message = "";
        if (response != null) {
        	message = new String(response.getBody(), "UTF-8");
        }
        return message;
	}
	
	
	private static void determinePrice(String message) {
		price = 0;
		if(message.length()>0) {
			String[] messageParts = message.split(";");
			uuid = messageParts[0];
			String item = messageParts[1];
			int quantity = Integer.parseInt(messageParts[2]);
			System.out.println("Request received");
			System.out.println("Message no. " + uuid);
			System.out.println("Requested item: " + item);
			System.out.println("Requested quantity: " + quantity);
			System.out.println("Please enter your price: ");

			price = in.nextInt();
			System.out.println();
		}
	}
	
	private static void sendQuotation() throws Exception{
		channel.queueDeclare("quotations", false, false, false, null);
		String message = uuid + ";" + price;
		channel.basicPublish("", "quotations", null, message.getBytes());
	}

	private static void printAnswer(String message) {
		if(message.length()>0) {
			String[] messageParts = message.split(";");
			uuid = messageParts[0];
			boolean accepted = Boolean.parseBoolean(messageParts[1]);
			System.out.println("Answer received");
			System.out.println("Message no. " + uuid);
			System.out.println("Quotation accepted? " + accepted);
			System.out.println();
		}
	}
	

	

}
